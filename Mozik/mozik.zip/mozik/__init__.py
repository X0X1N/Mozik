__all__ = ["core", "detect", "pipelines", "cli"]
